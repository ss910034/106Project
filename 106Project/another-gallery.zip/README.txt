A Pen created at CodePen.io. You can find this one at https://codepen.io/nakome/pen/sIcin.

 Responsive gallery with list style and custom lightbox.
Photos: unsplash.com.
