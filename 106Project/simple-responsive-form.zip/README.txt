A Pen created at CodePen.io. You can find this one at https://codepen.io/icorrea/pen/GNGyXv.

 This is an easy responsive form build in two columns and using media queries 